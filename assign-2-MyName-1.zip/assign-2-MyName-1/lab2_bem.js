window.onload = function() {
  var username = document.getElementById("username");
  var password = document.getElementById("password");
  var output = document.getElementById("output");

  var authForm = document.forms[0];

  function validate() {
    if (username.value === "") {
      username.style.backgroundColor = "red";
    }
    if (password.value === "") {
      password.style.backgroundColor = "red";
    }

    if (username.value !== "" && password.value !== "") {
      username.style.backgroundColor = "#FEF5E7";
      password.style.backgroundColor = "#FEF5E7";
    }
    var outputValue = checkLogin(username.value, password.value);
    output.innerHTML = outputValue === true ? "Welcome back!" : outputValue;
    return false;
  }

  authForm.onsubmit = validate;
};
