/**
 * MD5 Encryption function to encrypt provided string.
 * Returns string of encrypted hash.
 * @param {string} stringUserName
 * @param {string} stringPassword
 */
var userName = "d3c654d99bdfaf101e012bfe2810679e"; //USERNAME is bem
var password = "d153a57099a9679a3d94facaee3c6991"; //PASSWORD is bem_2
function checkLogin(stringUserName, stringPassword) {
  if (stringUserName === "") {
    return "No Username Entered";
  }
  if (stringPassword === "") {
    return "No Password Entered";
  }
  if (stringUserName !== "" && stringPassword !== "") {
    return md5Encrypt(stringUserName) === userName &&
      md5Encrypt(stringPassword) === password
      ? true
      : "Invalid Username or Password";
  }

  return false;
} //END checkLogin
