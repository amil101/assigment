describe("Test md5Encrypt Function", function() {
  it("if the username is an empty", function() {
    //WHEN
    var output = md5Encrypt("stringValue");

    //THEN
    expect(output).toMatch("5b57ab60c984eec4bc98143f6d1e8775");
  });
});

describe("Test checkLogin Function", function() {
  it("if the username is an empty", function() {
    //WHEN
    var output = checkLogin("", "password");

    //THEN
    expect(output).toEqual("No Username Entered");
  });

  it("if the password is an empty", function() {
    //WHEN
    var output = checkLogin("userName", "");

    //THEN
    expect(output).toEqual("No Password Entered");
  });

  it("if the username and the password match a known username and matching password", function() {
    //WHEN
    var output = checkLogin("bem", "bem_2");

    //THEN
    expect(output).toEqual(true);
  });

  describe("Should Return Invalid Username or Password", function() {
    var outputString = "Invalid Username or Password";
    it("if the username input does not match a known username", function() {
      //WHEN
      var output = checkLogin("invaliduserName", "invalidpassword");

      //THEN
      expect(output).toEqual(outputString);
    });

    it("a valid username is input with an invalid password", function() {
      //WHEN
      var output = checkLogin("bem", "invalidPassword");

      //THEN
      expect(output).toEqual(outputString);
    });

    it("an invalid username is input with a valid password", function() {
      //WHEN
      var output = checkLogin("invalidUserName", "bem_2");

      //THEN
      expect(output).toEqual(outputString);
    });
  });
});
